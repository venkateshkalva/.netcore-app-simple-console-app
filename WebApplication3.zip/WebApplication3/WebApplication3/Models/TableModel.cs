﻿namespace WebApplication3.Models
{
    public class TableModel
    {
        public string Query { get; set; }
        public string[] TableNames { get; set; }
        public string[] Columns { get; set; }
    }
}
