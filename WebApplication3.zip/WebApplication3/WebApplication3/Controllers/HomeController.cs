﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text.RegularExpressions;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpPost]
        public IActionResult PostData(TableModel tableModel)
        {
            string[] tableName = ExtractTableNames(tableModel.Query);
            string[] columnNames = ExtractColumnNames(tableModel.Query);
            return View("Index",new TableModel() { Columns = columnNames, TableNames = tableName });
        }
        public IActionResult Index()
        {
           return View();
        }
        private string[] ExtractColumnNames(string sqlScript)
        {
            Regex regex = new Regex(@"SELECT\s+(.*?)\s+FROM", RegexOptions.IgnoreCase);
            Match match = regex.Match(sqlScript);
            if(match.Success)
            {
                string columnList = match.Groups[1].Value;
                return columnList.Split(',');
            }
            return new string[0];
        }
        private string[] ExtractTableNames(string sqlScript)
        {
            Regex regex = new Regex(@"(?:FROM|JOIN)\s+(\S+)", RegexOptions.IgnoreCase);
            MatchCollection matches  = regex.Matches(sqlScript);
            string[] tableNames = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                tableNames[i] = matches[i].Groups[1].Value;
            }
            return tableNames;
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}